# TODO(nabenabe0928): Come up with any ways to remove this file.
# NOTE(nabenabe0928): Discuss when to remove this class.
raise ModuleNotFoundError(
    "`optuna.multi_objective` was removed at v4.0.0. "
    "Please update your code or downgrade your Optuna version."
)
